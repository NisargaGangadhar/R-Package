#' Fits Gaussian process and creates predictions on climate data by optimising the hyperparameter
#'
#' @param obj An object of class \code{climr} Output from \code{\link{load_clim}} function
#'
#' @param method_type The type of optimisation method required, either Nelder-Mead (\code{Nelder-Mead}), BFGS(\code{BFGS}),SANN(\code{SANN}) or Brent (\code{Brent})
#'
#' @return Returns a list of class \code{climr_gp_fit} which includes the predicted values as well as the data set and optim method type used
#' @seealso \code{\link{load_clim}}, \code{\link{plot.climr_gp_fit}}, \code{\link{plot.climr_fit}}, \code{\link{fit}}
#' @export
#' @importFrom magrittr "%$%"
#' @importFrom stats "optim"
#' @importFrom stats "sd"
#' @importFrom mvtnorm "dmvnorm"
#' @importFrom tibble "tibble"
#'
#' @examples
#' ans1 = load_clim('NH')
#' ans2 = gp_fit(ans1, 'BFGS')
#'
#' @export
gp_fit <- function(obj,  method_type = c('Nelder-Mead','BFGS', 'SANN', 'Brent')) {
  UseMethod('gp_fit')
}

# Define criterion to be minimised in Gaussian process regression
gp_criterion = function(p,x,y)
{
  sig_sq = exp(p[1])
  rho_sq = exp(p[2])
  tau_sq = exp(p[3])
  Mu = rep(0, length(x))
  Sigma = sig_sq * exp( - rho_sq * outer(x, x, '-')^2 ) + tau_sq * diag(length(x))
  ll = dmvnorm(y, Mu, Sigma, log = TRUE)
  return(-ll)
}

#' @export
gp_fit.climr <- function(obj, method_type = c('Nelder-Mead','BFGS', 'SANN', 'Brent')) {#main function

  # Create global variables to avoid annoying CRAN notes
  DJF = Dec = `J-D` = Jan = SON = Year = month = pred = quarter = temp = x = year = NULL

  # Find what type of optimization method
  method_arg <- match.arg(method_type)

  #scaling the variables temp and year, creating grid values
  x=scale(obj$clim_year$year)[,1]
  y=scale(obj$clim_year$temp)[,1]
  x_g=pretty(x, n = 100)

  #Gaussian process applying optim method
  answer <- optim(rep(0, 3), gp_criterion,x=x,y=y,method = method_arg)
  sig_sq <- exp(answer$par[1])
  rho_sq <- exp(answer$par[2])
  tau_sq <- exp(answer$par[3])

  # Create covariance matrices
  C <- sig_sq * exp( - rho_sq * outer(x_g, x, '-')^2 )
  Sigma <- sig_sq * exp( - rho_sq * outer(x, x, '-')^2 ) + tau_sq * diag(length(x))

  # Now create predictions after unscaling the data back
  pred <- C %*% solve(Sigma, y)
  x_g1 <- x_g* sd(obj$clim_year$year) + mean(obj$clim_year$year)
  pred1 <- pred* sd(obj$clim_year$temp) + mean(obj$clim_year$temp)

  #create th list of output
  out <- list(data = obj$clim_year,
              predicted_values = tibble(pred1,x_g1),
              method=method_arg)
  class(out) <- 'climr_gp_fit'

  return(out)
}
