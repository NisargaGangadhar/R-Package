#' Plots gp_fit.climr output
#'
#' @param x Output from the \code{\link{gp_fit}} function
#' @param ... Other arguments to plot (not currently implemented)
#'
#'
#' @return A plot illustrating the data as a scatterplot, adds the smoothed Guassian process regression line
#' @seealso \code{\link{load_clim}}, \code{\link{gp_fit}}, \code{\link{plot.climr_fit}}, \code{\link{fit}}
#' @export
#' @import ggplot2
#' @importFrom viridis "scale_color_viridis"
#'
#' @examples
#' ans1 = load_clim('NH')
#' ans2 = gp_fit(ans1,'BFGS')
#' plot(ans2)


plot.climr_gp_fit <- function(x, ...) {

  # Create global variables to avoid annoying CRAN notes
  DJF = Dec = `J-D` = Jan = SON = Year = month = pred = quarter = temp = year = NULL


  # Get the data set out
  df <- x$data
  a<-x$predicted_values$x_g1
  b<-x$predicted_values$pred1
  df1 <-tibble(a,b)

  # Finally create the plot
  ggplot(df, aes(year, temp)) +
    geom_point(aes(colour = temp)) +
    theme_bw() +
    xlab('Year') +
    ylab('Temperature anomaly') +
    geom_line(data=df1,aes(x = a, y =b, colour = b),lwd=1) +
    theme(legend.position = 'None') +
    scale_color_viridis()
}
